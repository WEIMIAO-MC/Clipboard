<?php //页面结尾 ?>
    <div class="copyright">
            <p>友情链接：</p>
            <span class="left">© 2019 <a href="https://weimiao.xin/">微缈WeiMiao</a></span>
            <span class='right'>备案号：粤ICP备18069216号</span>
    </div>
</div>
</body>
</html>
<script>new ClipboardJS('.copy');</script>
