<?php //页面开头 ?>
<?php include("php/login.php");include("php/constant.php");?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>剪贴板-微渺WeiMiao</title>
    <script src="/js/jquery-3.4.0.min.js"></script>
    <script src="/js/function.js"></script>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.0/clipboard.min.js"></script>
</head>
<body>
<div class="dh">
    <span id = "info"><?php if($information == ""){echo "欢迎访问本站本站的域名是'".$Website."'";}else{echo $information;}?></span>
    <div class = "Navigation">
        <ul>
            <li><a href="<?php echo $Website;?>">首页</a></li>
            <?php if($_COOKIE["user_id"] == ""){?>
                <li><a href="javascript:;" id = "login">登录</a></li>
                <li><a href="javascript:;" id = "regis">注册</a></li>
            <!--<a href="javascript:;">个人</a>-->
            <?php }else {?>
                <li><a href="javascript:;" id = "logout">退出登录</a></li>
                <li><a href="javascript:;" id = "refresh">刷新</a></li>
            <?php }?>
        </ul>
        <div class="text_line"></div>
    </div>
</div>
<div class="Centered" id="Centered">