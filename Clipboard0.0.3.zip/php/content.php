<?php
include("sql.php");
$sql = "SELECT ID,name FROM wm_user where name = '".$_COOKIE['user_name']."' AND ID ='".$_COOKIE["user_id"]."'";
$result = $conn->query($sql);

unset($sql);

if($result->num_rows == 1){ //用户判断

    unset($result);
    if($_POST["content"] != ""){
        $sql = "SELECT content FROM wm_Scrapbooking WHERE user_ID = '".$_COOKIE["user_id"]."' ORDER BY ID DESC";
        $result = $conn->query($sql);
        if ($result->num_rows > 0){
            while($row = $result->fetch_assoc()){
                $contenttow = $row["content"];
                break;
            }
        }
		if(htmlentities($_POST["content"]) != $contenttow && $content != $_POST["content"]){
			date_default_timezone_set("PRC");
			$date = date("Y-m-d H:i:s");
			$content = htmlentities($_POST["content"]);
			$sql = "INSERT INTO wm_Scrapbooking VALUES (NULL,'".$_COOKIE["user_id"]."','".$content."','".$date."')";
            if($conn->query($sql) === TRUE){
                echo "提交成功".$date;
			}else{
				echo "提交失败". mysqli_error($conn);
			}
		}else{
			echo "内容相同，禁止提交！";
		}
	}else{
        echo "提交的值为空！";
	}
}else{
	echo "用户未登陆";
	unset($_COOKIE['user_id']);
	unset($_COOKIE['user_name']);
}
	unset($_POST['content']);
	unset($content);
	unset($sql);
	unset($date);
$conn->close();
?>