<?php
include("../php/constant.php");
include("../php/sql.php");
// 允许上传的后缀
$sql = "SELECT ID,name FROM wm_user where name = '".$_COOKIE['user_name']."' AND ID ='".$_COOKIE["user_id"]."'";
$result = $conn->query($sql);

unset($sql);

if($result->num_rows == 1){ //用户判断

    unset($result);

    $allowedExts = array("zip");
    $temp = explode(".", $_FILES["file"]["name"]);
    $extension = end($temp);     // 获取文件后缀名
    if (($_FILES["file"]["size"] < 10485760)   // 小于 200 kb
    && in_array($extension, $allowedExts) && !($conn->connect_error))
    {
        if ($_FILES["file"]["error"] > 0)
        {
            echo "错误：: " . $_FILES["file"]["error"] . "<br>";
        }
        else
        {
            echo "上传文件名: " . $_FILES["file"]["name"] . "<br>";
            echo "文件类型: " . $_FILES["file"]["type"] . "<br>";
            echo "文件大小: " . ($_FILES["file"]["size"] / 1024) . " kB<br>";
            echo "文件临时存储的位置: " . $_FILES["file"]["tmp_name"] . "<br>";
            $sql = "INSERT INTO `wm_file` (`ID`, `name`, `pass`, `email`) VALUES (NULL,'".$user ."','".$pass."','".$mail."')";
            
            $dir = iconv("UTF-8", "GBK", "../upload/".date("Y-m-d")."/");
            if(!file_exists($dir)){
                mkdir ($dir,0755,true);
                echo "创建目录成功";
            }else{
                echo "目录已存在";
            }

            // 判断当期目录下的 upload 目录是否存在该文件
            // 如果没有 upload 目录，你需要创建它，upload 目录权限为 777
            if (file_exists("../upload/".date("Y-m-d")."/".date("Y-m-d-H-i-s").$_FILES["file"]["name"]))
            {
                echo $_FILES["file"]["name"] . " 文件已经存在。 ";
            }
            else
            {
                $addr = "../upload/".date("Y-m-d")."/";
                $name = $_FILES["file"]["name"];
                $name = date("Y-m-d-H-i-s").$_FILES["file"]["name"];
                $sql = "INSERT INTO `wm_file` (`ID`, `user_ID`, `Name`, `Name_real`, `date`, `addr`) VALUES (NULL,'".$_COOKIE["user_id"]."','".$name."','".$_FILES["file"]["name"]."','". date("Y-m-d-H-i-s") ."','".$Website ."/upload/".date("Y-m-d")."/". $name."')";
                if ($conn->query($sql) === TRUE) {
                    // 如果 upload 目录不存在该文件则将文件上传到 upload 目录下
                    move_uploaded_file($_FILES["file"]["tmp_name"], $addr . $name);
                    echo "文件存储在: " . $Website ."/upload/".date("Y-m-d")."/". $name;
                } else {
                    echo "文件储存失败！";
                }
            }
        }
    }
    else
    {
        echo "非法的文件格式".$extension;
    }
}else{
    echo "用户未登陆";
    
	unset($_COOKIE['user_id']);
	unset($_COOKIE['user_name']);
}
unset($addr);
unset($allowedExts);
unset($name);
unset($temp);
unset($extension);
unset($_FILES["file"]);
$conn->close();
echo "<script>location.href = '" . $Website. "';</script>";
?>
