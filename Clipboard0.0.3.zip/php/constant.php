﻿<?php
    $Page = 1;
    $Website = '';//使用前修改这个!为你的网站网址，注意不要加最后的“/”
    echo "<script> var Website = '". $Website ."';</script>";
?>