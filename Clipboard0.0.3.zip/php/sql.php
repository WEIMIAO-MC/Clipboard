﻿<?php
    $servername = "";//数据库地址
    $username = "";//登录用户名
    $password = "";//你的数据库密码
    $dbname = "";//数据库名称
    
    $conn= new mysqli($servername,$username,$password,$dbname); //连接数据库
?>