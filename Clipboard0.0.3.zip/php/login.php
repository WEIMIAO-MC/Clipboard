<?php
include("./php/sql.php");
if($_COOKIE['user_id'] == "" && $_COOKIE['user_name'] == ""){
switch($_POST["type"]){
    case '注册':
        $user = $_POST["regis_name"];
        $pass = $_POST["regis_pass"];
        $mail = $_POST["regis_mail"];
        if($user != "" && $pass != ""){
            if(preg_match("/^[a-zA-Z0-9_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]+$/",$user)){
                if (preg_match("/([A-Za-z0-9_\-\u4e00-\u9fa5]+)/",$mail)) {
                    if($pass == $_POST["regis_passtow"] && stristr($_POST["regis_passtow"]," ") === false){
                        $sql = "SELECT name from wm_user where name = '".$user."'";
                        $result = $conn->query($sql);
                        if($result->num_rows == 0){
                            $sql = "";
                            $result = "";
                            $sql = "SELECT email from wm_user where name = '".$mail."'";
                            $result = $conn->query($sql);
                            if($result->num_rows == 0){
                                $sql = "INSERT INTO `wm_user` (`ID`, `name`, `pass`, `email`) VALUES (NULL,'".$user ."','".$pass."','".$mail."')";
                                if ($conn->query($sql) === TRUE) {
                                    $information = "注册成功";
                                    $_POST["type"] = "";
                                    $sql = "";
                                    echo "<script>location.href = '" . $Website. "';</script>";
                                } else {
                                    $information = "注册失败";
                                    $sql = "";
                                    echo "<script>location.href = '" . $Website. "';</script>";
                                }
                            }else{
                                $information = "邮箱已存在";
                            }
                        }else{
                            $information = "用户名已存在";
                        }
                    }else{
                        $information = "密码不一致，密码不能带空格";
                    }
                }else{
                    $information = "邮箱不正确";
                }
            }else{
                $information = "用户名不合法";
            }
        }else{
            $information = "用户名不能为空";
        }
        $user = "";
        $pass = "";
        $mail = "";
        unset($_POST["regis_name"]);
        unset($_POST["regis_pass"]);
        unset($_POST["regis_mail"]);
        break;
    case '登录':
        $user = $_POST["login__name"];
        $pass = $_POST["login_pass"];
        if(preg_match("/^[a-zA-Z0-9_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]+$/",$user) && stristr($_POST["login__name"]," ") === false){
            $sql = "SELECT ID,name,pass FROM wm_user where name = '".$user."' AND pass ='".$pass."'";
            $result = $conn->query($sql);
            if($result->num_rows == 1){
                while($row = $result->fetch_assoc()){
                    if($_POST['duration'] == "一直登陆"){
                        setcookie("user_id",$row["ID"]);
                        setcookie("user_name",$row["name"]);
                    }else{
                        setcookie("user_id",$row["ID"],time()+3600);
                        setcookie("user_name",$row["name"],time()+3600);
                    }
                    echo "<script>location.href = '" . $Website. "';</script>";
                }
            }else{
                    $information = "账号或者密码错误（#001）";
            }
            $sql = "";
            $result = "";
            unset($_POST["login__name"]);
            unset($_POST["login_pass"]);
        }else{
            $information = "账号或者密码错误（#002）";
        }
        break;
    default:
        //$information = "无方法";
        break;
    }
}
unset($sql);
unset($_POST['type']);
$conn->close();
?>