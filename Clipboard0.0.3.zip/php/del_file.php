<?php 
    include("sql.php"); 
    $sql = "SELECT ID,name FROM wm_user where name = '".$_COOKIE['user_name']."' AND ID ='".$_COOKIE["user_id"]."'";
    $result = $conn->query($sql);
    unset($sql);
    if($result->num_rows == 1){ //用户判断
        unset($result);
        $sql = "SELECT Name , date FROM wm_file where ID = '" . $_POST["id"] . "' AND user_ID = '".$_COOKIE["user_id"]."'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $date = substr($row['date'] , 0 , 10);
                $files = "../upload/".$date."/".$row['Name'];
            }
            $sql = "DELETE FROM wm_file WHERE ID = '".$_POST["id"]."' AND user_ID = '".$_COOKIE["user_id"]."'";
            if($conn->query($sql) === TRUE)
            {
                unlink($files);
                echo "删除文件成功";
            }else{
                echo "删除文件失败";
            }
            $sql = "";
        }else{
        echo "删除失败！";
        }
    }else{
        echo "用户未登陆";
        
        unset($_COOKIE['user_id']);
        unset($_COOKIE['user_name']);
    }
    $conn->close();
?>