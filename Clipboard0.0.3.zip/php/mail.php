复制代码
<?php
  /**
   *  2014-08-25
   *  描述：PHP邮件发送
   *  使用PHPMailer类
   *  发送附件,多人发送
   *  发送附件
   *  发送附件的时候，鉴于本地网络和服务器的速度，如不能正常上传，修改php配置文件中的memory_limit限制
   *  其他可能的限制post_max_size  upload_max_filesize
   *  也可能要将max_execution_time修改
   *  请使用前确认发送邮件的邮箱帐号开启了SMTP
   */ 

     set_time_limit(0);                          //如果上传附件卡，将脚本执行限制时间修改为0
     require './class.phpmailer.php';
     require './class.smtp.php';
      date_default_timezone_set("Asia/Shanghai");//设定时区东八区
     $mail=new PHPMailer();                      //建立邮件发送类
     $mail->IsSMTP();                            //使用SMTP形式发送
     $mail->CharSet='utf-8';                     //编码
     $mail->SMTPDebug  = 1;                      // 启用SMTP调试功能
                                                 // 1 = errors and messages
                                                 // 2 = messages only
     
     $mail->SMTPAuth = true;                     // 启用SMTP验证功能
     $mail->Host='smtp.qq.com';                  //qq smtp 服务器,发送邮箱帐号公司的SMTP服务器
     $mail->Port=25;  　　　　　　　　　　　　　　　 // SMTP服务器的端口号
                              
     $mail->Username='1107989194@qq.com';        //这里填写发件邮箱账号
     $mail->Password='********';                 //这里填写发件邮箱的密码

     $mail->AddAddress('357966443@qq.com','bO莱特2');
     //$mail->AddAddress('1107989194@qq.com','风沙渡'); #多人发送
     $mail->IsHTML();
    //$a=$mail->AddAttachment('D:\wamp\www\user.sql','z.zip');//附件的绝对位置,上传后附件的名称
     $mail->Subject='发送自PHPMailer的邮箱';

     $mail->From='1107989194@qq.com';             //发送人的姓名  地址
     $mail->FromName='风沙渡';

     $mail->Body='测试一下4';
     $mail->AltBody='附加信息'; 
    
     if(!$mail->send()){
       echo '邮件发送失败'.'</br>';
       echo '错误原因'.$mail->ErrorInfo;
     }else{
        echo '邮件发送成功';
        
     }    
?>
