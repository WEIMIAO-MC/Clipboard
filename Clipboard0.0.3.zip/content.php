<script src="/js/ajax.js"></script>
<?php 
    include("./php/sql.php");
    $sql = "SELECT ID,name FROM wm_user where name = '".$_COOKIE['user_name']."' AND ID ='".$_COOKIE["user_id"]."'";
    $result = $conn->query($sql);
    unset($sql);
    if($result->num_rows == 1){ //用户判断
        unset($result);
?>
<?php include("file.php");?>
<div class="inputbox">
    <textarea class = "text" name="content" id="content"></textarea>
    <input type="submit" value="提交" id="content_submit" class="btn">
</div>
<div class="article">
    <ul>
        <?php
            $sql = "SELECT s.ID ,s.content , s.date  FROM wm_Scrapbooking s where s.user_ID = '" . $_COOKIE["user_id"] . "' ORDER BY s.ID DESC ";
            $result = $conn->query($sql);
            unset($sql);
            if ($result->num_rows > 0) {
                // 输出数据
                while ($row = $result->fetch_assoc()) {
                    $count++;
                    if($count <= 50){
            ?>
                <li>
                    <span class="content_id"><?php echo $count?></span>
                    <span class="content"><?php echo $row["content"] ?></span>
                    <div class="function">
                        <span class="date">时间：<?php echo $row["date"] ?></span><br />
                        <a href="javascript:;" class="copy" data-clipboard-action="copy" data-clipboard-text ="<?php echo $row["content"] ?>">复制</a>
                        <a href="javascript:;" onclick="content_id(<?php echo $row['ID']; ?>)">删除</a>
                    </div>
                    <div class="text_line"></div>
                </li>
                
            <?php }else{
                if($_COOKIE["user_id"] != "" && $_COOKIE["user_name"] != "")
                {
                    $sql = "DELETE FROM wm_Scrapbooking WHERE user_id = '".$_COOKIE["user_id"]."' AND ID = '".$row['ID']."'";
                    $conn->query($sql);
                    unset($sql);
                }
            }}
            $conn->close();
            }?>
    </ul>
<?php }else{?>
    <ul>
        <li>请登陆<br />登陆后可以享受文件上传，内容提交，在其他终端使用浏览器打开本网站！</li>
    </ul>
<?php 
	unset($_COOKIE['user_id']);
    unset($_COOKIE['user_name']);
}?>
</div>