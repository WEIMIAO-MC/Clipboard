<?php //注册页面 ?>
<script language="javascript" type="text/javascript">
 //禁用Enter键表单自动提交
        document.onkeydown = function(event) {
            var target, code, tag;
            if (!event) {
                event = window.event; //针对ie浏览器
                target = event.srcElement;
                code = event.keyCode;
                if (code == 13) {
                    tag = target.tagName;
                    if (tag == "TEXTAREA") { return true; }
                    else { return false; }
                }
            }
            else {
                target = event.target; //针对遵循w3c标准的浏览器，如Firefox
                code = event.keyCode;
                if (code == 13) {
                    tag = target.tagName;
                    if (tag == "INPUT") { return false; }
                    else { return true; }
                }
            }
        };
</script>
<div class="loginpiece">
    <form method="post" action="<?php echo $Website; ?>">
        账号：<br /><input type="text" name="regis_name"><br />
        密码：<br /><input type="password" name="regis_pass"><br />
        确认密码：<br /><input type="password" name="regis_passtow"><br />
        个人邮箱<br /><input type="email" name="regis_mail"><br />
        <input type="submit" value="注册">
        <input type="hidden" name="type" value="注册">
        <p>点击注册，默认已经同意了隐私条例</p><br />
    </form>
    <span class="txt">隐私条例</span><br />
  <span class="txt"><a href="javascript:;" id="login">已经注册？点击登录</a></span>
    <!--<span class="txt">忘记密码？找回密码</span>-->
</div>
