-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: 2019-05-27 23:40:15
-- 服务器版本： 5.5.57-log
-- PHP Version: 7.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kf_weimiao_xin`
--

DELIMITER $$
--
-- 存储过程
--
$$

$$

$$

$$

$$

$$

$$

$$

$$

$$

$$

$$

$$

DELIMITER ;

-- --------------------------------------------------------

--
-- 表的结构 `wm_file`
--

CREATE TABLE `wm_file` (
  `ID` int(11) NOT NULL COMMENT '文件ID',
  `user_ID` int(11) NOT NULL COMMENT '用户ID',
  `Name` text NOT NULL COMMENT '文件名称',
  `Name_real` text NOT NULL COMMENT '文件名称（真）',
  `date` text NOT NULL COMMENT '时间',
  `addr` text NOT NULL COMMENT '下载地址'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `wm_Scrapbooking`
--

CREATE TABLE `wm_Scrapbooking` (
  `ID` int(11) NOT NULL COMMENT '剪贴ID',
  `user_ID` int(11) NOT NULL COMMENT '用户ID',
  `content` text NOT NULL COMMENT '剪贴内容',
  `date` text NOT NULL COMMENT '时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `wm_user`
--

CREATE TABLE `wm_user` (
  `ID` int(11) NOT NULL COMMENT '用户ID',
  `name` text NOT NULL COMMENT '用户名',
  `pass` text NOT NULL COMMENT '密码',
  `email` text NOT NULL COMMENT '电子邮件'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wm_file`
--
ALTER TABLE `wm_file`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `wm_Scrapbooking`
--
ALTER TABLE `wm_Scrapbooking`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `wm_user`
--
ALTER TABLE `wm_user`
  ADD PRIMARY KEY (`ID`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `wm_file`
--
ALTER TABLE `wm_file`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '文件ID';

--
-- 使用表AUTO_INCREMENT `wm_Scrapbooking`
--
ALTER TABLE `wm_Scrapbooking`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '剪贴ID';

--
-- 使用表AUTO_INCREMENT `wm_user`
--
ALTER TABLE `wm_user`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户ID';

DELIMITER $$
--
-- 事件
--
CREATE DEFINER=`root`@`localhost` EVENT `AutoUpdateFileRestTime` ON SCHEDULE EVERY 1 MINUTE STARTS '2018-10-03 16:31:56' ON COMPLETION NOT PRESERVE ENABLE DO CALL TimeDEC()$$

DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
