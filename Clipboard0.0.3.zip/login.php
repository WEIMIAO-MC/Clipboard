<?php //登录页面 ?>
<div class="loginpiece">
    <form method="post" action="<?php echo $Website; ?>">
        账号<br /><input type="text" name="login__name"><br />
        密码<br /><input type="password" name="login_pass"><br />
        登陆时长<br /><input type="radio" name="duration" checked="value" value="一小时">一小时|<input type="radio" name="duration" value = "一直登陆">一直登陆
        <input type="hidden" name="type" value="登录">
        <input type="submit" value="登录">
    </form>
  	<span class="txt"><a href="javascript:;" id="regis">没有账号？点击注册</a></span>
    <!--<span class="txt">忘记密码？找回密码</span>-->
</div>