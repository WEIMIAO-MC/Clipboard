$(document).ready(function() {
	$('#login').click(function() {
		$('#Centered').load('/login.php');
	});
	$('#regis').click(function() {
		$('#Centered').load('/regis.php');
	});
	$('#content_submit').click(function(){
		$.post("/php/content.php",
			{
				content:$('#content').val()
			}
			,
			function(info){
				$('#Centered').load('/content.php');
				$('#info').text(info);
			}
		);
	});
	$('#refresh').click(function() {
		$('#Centered').load('/content.php');
		$('#info').text("刷新成功!");
    });
    /*$('Upload').click(function(){
        $.post("./php/upload.php",)
    });*/

});
function content_id(data) {
	var r = confirm('确认删除？');
	if (r == true) {
		$.post(
			'./php/del_content.php',
			{
				content_id:data
			},
			function(status) {
				if (status == '删除成功') {
					$('#Centered').load('/content.php');
					$('#info').text("删除成功!");
				} else {
					alert('删除失败');
				}
			}
		);
	} else {
	}
}
function del_file(id) {
	var r = confirm('确认删除？');
	if (r == true) {
		$.post(
			'./php/del_file.php',
			{
				id:id
			},
			function(status) {
				if (status == '删除文件成功') {
					$('#Centered').load('/content.php');
					$('#info').text("删除文件成功!");
				} else {
					alert(status);
					alert('删除文件失败');
				}
			}
		);
	} else {
	}
}