$(document).ready(function() {
	$('#logout').click(function() {
		var name = 'user_id';
		var date = new Date();
		date.setTime(date.getTime() - 10000);
		document.cookie = name + '=v; expires=' + date.toGMTString();
		var name = 'user_name';
		var date = new Date();
		date.setTime(date.getTime() - 10000);
		document.cookie = name + '=v; expires=' + date.toGMTString();
		location.href = Website;
	});
});
