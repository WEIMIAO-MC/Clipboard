<div class="file">
    <ul>
        <h3>上传最多十个每个不得大于"5MB"格式为"zip"格式</h3>
    <?php 
    include("./php/sql.php");
    $sql = "SELECT ID ,Name_real,Name , addr ,date  FROM wm_file where user_ID = '" . $_COOKIE["user_id"] . "' ORDER BY ID DESC ";
    $result = $conn->query($sql);
    unset($sql);
    if ($result->num_rows > 0) {
        // 输出数据
        while ($row = $result->fetch_assoc()) {
            $count++;
            $date = substr($row['date'] , 0 , 10);
            $files = "./upload/".$date."/".$row['Name'];
            if($count <= 10){
        ?>
            <li><span class="name"><a href="<?php echo $row['addr'];?>"><?php echo $row['Name_real'];?></a></span><span class="date"><?php echo $row['date'] ;?></span><span id="del"><a href="javascript:;"  onclick="del_file(<?php echo $row['ID']; ?>)">删除</a></span></li>
        <?php }else {
                $sql = "DELETE FROM wm_file WHERE ID = '".$row["ID"]."' AND user_ID = '".$_COOKIE["user_id"]."'";
                if($conn->query($sql) === TRUE)
                {
                    unlink($files);
                }
            }
            $count = 0;
        }
    }?>
    </ul>
    <div class = "upload_file">
    <form action="../php/upload.php" method="post" enctype="multipart/form-data">
        <label for="file">文件名：</label>
        <input type="file" name="file" id="file">
        <input type="submit" name="submit" value="提交">
    </form>
    </div>
</div>